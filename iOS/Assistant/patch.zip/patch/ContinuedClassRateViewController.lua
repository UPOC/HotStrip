waxClass{"TaQrCodeViewModel"}

function initializeLoadURL(self)

 	print("222222222")

 
end
