waxClass{"TaQrCodeViewModel"}

function initializeLoadURL(self)

  -- 	loacal realm =  RLMRealm:defaultRealm();
  --   loacal whereStr = 'userId contains ' .. tostring(SSKeychain:userId())..' AND schoolId CONTAINS '..tostring(SSKeychain:schoolID())




 	-- print(whereStr)
print('nudedamjenfurfu')
 return 
end
