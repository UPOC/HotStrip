waxClass{"TaQrCodeViewModel"}

function yyinitializeLoadURL(self)

  -- 	loacal realm =  RLMRealm:defaultRealm();
  --   loacal whereStr = 'userId contains ' .. tostring(SSKeychain:userId())..' AND schoolId CONTAINS '..tostring(SSKeychain:schoolID())




 	-- print(whereStr)
print("nudedamjenfurf")
 return 
end
