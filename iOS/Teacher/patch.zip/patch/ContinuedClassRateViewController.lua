waxClass{"ContinuedClassRateViewController", UTTableViewController}

function testWax(self)

 	print("222222222")
end
