waxClass{"ContinuedClassRateViewController"}

function testWax(self)

 	print("222222222")
end
